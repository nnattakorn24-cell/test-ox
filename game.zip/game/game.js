/* ============================================================
   game.js — เอนจินหลัก: state machine, สถิติ, ไทม์ไลน์, บันทึก
   ============================================================ */
(function () {
  const D = GAME_DATA;
  const ui = document.getElementById("ui");
  const hud = document.getElementById("hud");
  const modal = document.getElementById("modal");
  const pauseEl = document.getElementById("pause");
  const fader = document.getElementById("fader");
  const toast = document.getElementById("toast");

  const YEAR_MIN = 2411, YEAR_MAX = 2483;
  const REIGN_END = 2453;

  /* ---------------- สถานะเกม ---------------- */
  let G = null;           // ข้อมูลชีวิตปัจจุบัน
  let records = loadRecords();
  let screen = "title";   // title | setup | play | ending | gallery
  let paused = false;
  let modalOpen = false;

  function freshState() {
    return {
      name: "", gender: "m", origin: null, dream: null,
      stats: { hp: 50, wis: 30, gold: 30, honor: 30, joy: 50 },
      flags: [], log: [], stageIdx: 0, dead: false, year: D.birthYear,
    };
  }

  /* ---------------- localStorage ---------------- */
  function loadRecords() {
    try {
      const r = JSON.parse(localStorage.getItem("r5_records") || "null");
      if (r && Array.isArray(r.endings)) return r;
    } catch (e) { /* fallthrough */ }
    return { endings: [], lives: 0, best: 0 };
  }
  function saveRecords() {
    try { localStorage.setItem("r5_records", JSON.stringify(records)); } catch (e) {}
  }

  /* ---------------- ยูทิลิตี้ ---------------- */
  const TH_D = "๐๑๒๓๔๕๖๗๘๙";
  const th = (n) => String(n).replace(/\d/g, (d) => TH_D[+d]);
  const clamp = (v) => Math.max(0, Math.min(100, Math.round(v)));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  function esc(s) { const d = document.createElement("div"); d.textContent = s; return d.innerHTML; }

  function showToast(msg, ms = 2600) {
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove("show"), ms);
  }

  function fade(cb) {
    fader.classList.add("on");
    setTimeout(() => { cb(); fader.classList.remove("on"); }, 580);
  }

  /* ---------------- พื้นหลัง ---------------- */
  let bgFlip = false;
  function setBG(key, fxMode) {
    const a = document.getElementById("bg-a"), b = document.getElementById("bg-b");
    const showEl = bgFlip ? a : b, hideEl = bgFlip ? b : a;
    showEl.style.backgroundImage = `url("assets/${key}.jpg")`;
    showEl.classList.add("show"); hideEl.classList.remove("show");
    bgFlip = !bgFlip;
    FX.setMode(fxMode || (key === "night" ? "firefly" : key === "village" || key === "forest" ? "petal" : "dust"));
  }

  /* ---------------- HUD ---------------- */
  function renderStats() {
    const box = document.getElementById("stats");
    box.innerHTML = "";
    for (const k of ["hp", "wis", "gold", "honor", "joy"]) {
      const m = D.statMeta[k];
      const val = (G && G.stats && typeof G.stats[k] === "number") ? G.stats[k] : 50;
      const el = document.createElement("div");
      el.className = "stat"; el.dataset.k = k;
      el.innerHTML = `<span class="s-ico">${m.ico}</span>
        <span class="s-name">${m.name}</span>
        <span class="s-bar"><span class="s-fill" style="display:block;height:100%;border-radius:inherit;width:${val}%;background:${m.color}"></span></span>`;
      box.appendChild(el);
    }
  }

  function animateStatDeltas(deltas) {
    for (const k of Object.keys(deltas)) {
      const el = document.querySelector(`.stat[data-k="${k}"]`);
      if (!el) continue;
      const d = deltas[k];
      const fill = el.querySelector(".s-fill");
      if (fill && G && G.stats) {
        fill.style.width = G.stats[k] + "%";
      }
      el.classList.remove("pulse"); void el.offsetWidth; el.classList.add("pulse");
      const tag = document.createElement("span");
      tag.className = "delta " + (d >= 0 ? "up" : "down");
      tag.textContent = (d >= 0 ? "+" : "") + d;
      el.appendChild(tag);
      setTimeout(() => tag.remove(), 1700);
    }
  }

  function setTimeline(year, ageLabel) {
    const cursor = document.getElementById("timeline-cursor");
    const reign = document.getElementById("timeline-reign");
    const pct = (y) => ((y - YEAR_MIN) / (YEAR_MAX - YEAR_MIN)) * 100;
    cursor.style.left = pct(Math.min(year, YEAR_MAX)) + "%";
    reign.style.left = "0%";
    reign.style.width = pct(REIGN_END) + "%";
    document.getElementById("hud-year").textContent = "พ.ศ. " + th(year);
    document.getElementById("hud-age").textContent = ageLabel;
  }

  /* ---------------- โมดัลเหตุการณ์ ---------------- */
  function showModal(card, cb) {
    modalOpen = true;
    document.getElementById("modal-ribbon").textContent = card.ribbon || "📰 ข่าวในแผ่นดิน";
    document.getElementById("modal-title").textContent = card.title;
    document.getElementById("modal-year").textContent = card.year || "";
    document.getElementById("modal-text").textContent = card.text;
    const effBox = document.getElementById("modal-effect");
    if (card.effect) {
      const deltas = applyEffects(card.effect, false);
      effBox.innerHTML = deltas.map(([k, v]) =>
        `<span style="color:${v >= 0 ? "#2e7d4f" : "#b34747"}">${D.statMeta[k].ico} ${v >= 0 ? "+" : ""}${v}</span>`
      ).join(" ");
      animateStatDeltas(Object.fromEntries(deltas));
      AudioSys.sfx(card.effect.joy < 0 || card.effect.hp < 0 ? "gong" : "bell");
    } else {
      effBox.innerHTML = "";
      AudioSys.sfx("bell");
    }
    modal.classList.remove("hidden");
    document.getElementById("modal-ok").onclick = () => {
      modal.classList.add("hidden");
      modalOpen = false;
      AudioSys.sfx("page");
      cb && cb();
    };
  }

  /* ---------------- ผลกระทบต่อสถิติ ---------------- */
  function applyEffects(eff, luck = true) {
    const deltas = [];
    const luckRoll = luck ? Math.round(rnd(-2, 3)) : 0;
    for (const k of Object.keys(eff)) {
      let d = eff[k];
      if (luck && d !== 0) d += d > 0 ? Math.max(0, luckRoll) : Math.min(0, luckRoll);
      const before = G.stats[k];
      G.stats[k] = clamp(before + d);
      const real = G.stats[k] - before;
      if (real !== 0) deltas.push([k, real]);
    }
    return deltas;
  }

  function checkDeath() {
    if (G.stats.hp > 0) return false;
    G.dead = true;
    return true;
  }

  /* ============================================================
     หน้าจอต่าง ๆ
     ============================================================ */

  /* ---------- หน้าปก ---------- */
  function screenTitle() {
    screen = "title";
    hud.classList.add("hidden");
    setBG("title", "dust");
    ui.innerHTML = `
      <section id="screen-title" class="screen">
        <div class="title-frame">
          <div class="title-ornament">❦ ❦ ❦</div>
          <h1 class="game-title">หนึ่งในเจ็ดล้าน</h1>
          <div class="game-subtitle">ชีวิตในแผ่นดินรัชกาลที่ ๕</div>
          <p class="title-tagline">จำลองชีวิตหนึ่งชีวิตท่ามกลางสยามยุคปฏิรูป พ.ศ. ๒๔๒๑–๒๔๗๕<br>ทุกทางเลือกเขียนชะตาของเธอ — เหมือนคนจริง ๆ หนึ่งในเจ็ดล้านคน</p>
          <div class="title-buttons">
            <button id="btn-start" class="btn btn-primary">🌅 เริ่มชะตาชีวิต</button>
            <button id="btn-gallery" class="btn">📖 คลังตอนจบ</button>
          </div>
          <div id="title-records"></div>
          <div class="kbd-hint">เล่นง่าย ๆ ด้วยเมาส์/นิ้วสัมผัส • กด 1–3 เลือกทาง • M ปิดเสียง</div>
        </div>
      </section>`;
    const rec = document.getElementById("title-records");
    if (records.lives > 0) {
      rec.textContent = `เคยใช้ชีวิตแล้ว ${th(records.lives)} ชีวิต • บารมีสูงสุด ${th(records.best)} • ปลดล็อกตอนจบ ${th(records.endings.length)}/${th(D.endings.length)}`;
    }
    document.getElementById("btn-start").onclick = () => { AudioSys.unlock(); AudioSys.sfx("birth"); setupSel.origin = null; setupSel.dream = null; setupSel.name = ""; screenSetup(0); };
    document.getElementById("btn-gallery").onclick = () => { AudioSys.unlock(); AudioSys.sfx("page"); screenGallery(); };
    AudioSys.unlock();
  }

  /* ---------- หน้าเลือกฝันและแสดงผลสุ่มชีวิต (2 ขั้น) ---------- */
  const setupSel = { origin: null, dream: null, gender: "m", name: "" };

  function rollPersona() {
    setupSel.gender = pick(["m", "f"]);
    const originObj = pick(D.origins);
    setupSel.origin = originObj ? originObj.id : D.origins[0].id;
    setupSel.name = pick(D.names[setupSel.gender]);
  }

  function screenSetup(step) {
    screen = "setup";
    AudioSys.sfx("page");
    const dots = `<div class="setup-steps">${[0, 1].map(i => `<div class="step-dot ${i <= step ? "on" : ""}"></div>`).join("")}</div>`;

    if (step === 0) {
      // ขั้นที่ 1: เลือกความฝัน
      ui.innerHTML = `
        <section class="screen"><div class="setup-wrap">
          <h2 class="setup-title">ความฝันในหัวใจ</h2>
          <p class="setup-sub">เลือกสิ่งที่เธอปรารถนาที่สุด — ตอนจบจะตัดสินว่าฝันของเธอเป็นจริงหรือไม่</p>
          ${dots}
          <div class="cards-grid">
            ${D.dreams.map(dr => `
              <div class="pick-card" data-id="${dr.id}">
                <span class="pc-ico">${dr.ico}</span>
                <h3>${dr.name}</h3>
                <p>${dr.desc}</p>
              </div>`).join("")}
          </div>
        </div></section>`;
      ui.querySelectorAll(".pick-card").forEach(c => {
        c.onclick = () => {
          setupSel.dream = c.dataset.id;
          AudioSys.sfx("chime");
          c.classList.add("selected");
          rollPersona(); // สุ่มชื่อ เพศ และต้นกำเนิดทันที
          setTimeout(() => screenSetup(1), 380);
        };
      });
    } else {
      // ขั้นที่ 2: แสดงผลการสุ่มตัวละคร
      if (!setupSel.origin) rollPersona();

      const originObj = D.origins.find(o => o.id === setupSel.origin) || D.origins[0];
      const genderLabel = setupSel.gender === "m" ? "ชาย" : "หญิง";

      ui.innerHTML = `
        <section class="screen"><div class="setup-wrap" style="max-width:640px">
          <h2 class="setup-title">ชะตาชีวิตของคุณ</h2>
          <p class="setup-sub">โชคชะตาได้กำหนดชื่อ เพศ และต้นกำเนิดให้คุณเรียบร้อยแล้ว</p>
          ${dots}
          <div class="paper-panel" style="margin-top:4px">
            <div style="background:rgba(0,0,0,0.04); border:1px dashed #a38252; padding:20px; border-radius:8px; text-align:center; margin-bottom:16px;">
              <div style="font-size:0.9em; color:#666; margin-bottom:8px;">🎲 ชะตาชีวิตของคุณ:</div>
              <div style="font-size:1.2em; font-weight:bold; color:#2c1d11; margin-bottom:8px;">
                ชื่อ: <span style="color:#4a2c11;">${setupSel.name}</span> &nbsp;|&nbsp; เพศ: <span style="color:#8b0000;">${genderLabel}</span>
              </div>
              <h3 style="margin:8px 0 4px 0; color:#4a2c11;">${originObj.ico} ${originObj.name} (${originObj.place})</h3>
              <p style="font-size:0.9em; margin:6px 0 0 0; color:#333;">${originObj.desc}</p>
            </div>

            <div class="center-row" style="margin-top:18px">
              <button id="btn-born" class="btn btn-primary">👶 เกิดแล้ว!</button>
            </div>
          </div>
        </div></section>`;

      // เริ่มชีวิต
      ui.querySelector("#btn-born").onclick = () => {
        startLife(setupSel.name, setupSel.gender);
      };
    }
  }

  /* ---------- เริ่มชีวิต ---------- */
  function startLife(name, gender) {
    G = freshState();
    G.name = name;
    G.gender = gender;
    G.origin = setupSel.origin;
    G.dream = setupSel.dream;
    const o = D.origins.find(x => x.id === G.origin) || D.origins[0];
    if (o && o.base) {
      G.stats = { ...o.base };
    }
    AudioSys.sfx("birth");
    fade(() => {
      hud.classList.remove("hidden");
      renderStats();
      setTimeline(D.birthYear, "แรกเกิด");
      playStage(0);
    });
  }

  /* ---------- วนบทชีวิต ---------- */
  function playStage(idx) {
    screen = "play";
    G.stageIdx = idx;
    const st = D.stages[idx];
    G.year = st.year;
    setTimeline(st.year, `อายุ ${th(st.age)} ปี`);
    setBG(st.bg);
    // แสดงการ์ดประวัติศาสตร์ทีละใบ แล้วเข้าฉาก
    const cards = [...st.history];
    const next = () => {
      if (cards.length) { showModal(cards.shift(), next); return; }
      if (checkDeath()) { screenEnding(); return; }
      renderScene(st);
    };
    next();
  }

  function eligibleChoices(st) {
    const o = D.origins.find(x => x.id === G.origin) || D.origins[0];
    const ok = st.choices.filter(c => {
      if (c.gender && c.gender !== G.gender) return false;
      if (c.require) for (const k in c.require) if (G.stats[k] < c.require[k]) return false;
      if (c.flag_req && !G.flags.includes(c.flag_req)) return false;
      return true;
    });
    // จัดลำดับ: ที่ตรง origin ก่อน แล้วสุ่ม
    const match = ok.filter(c => c.tags.includes(G.origin) || (c.tags.includes("any") === false && c.tags.some(t => o.tags.includes(t))));
    const rest = ok.filter(c => !match.includes(c));
    const shuffled = (a) => a.sort(() => Math.random() - 0.5);
    const originSpecific = shuffled(ok.filter(c => c.tags.includes(G.origin)));
    const general = shuffled(ok.filter(c => !c.tags.includes(G.origin)));
    const chosen = [...originSpecific, ...general].slice(0, 3);
    return chosen.length >= 3 ? chosen : shuffled(ok).slice(0, 3);
  }

  function renderScene(st) {
    const o = D.origins.find(x => x.id === G.origin) || D.origins[0];
    const choices = eligibleChoices(st);
    G._currentChoices = choices;
    const intro = idx0Intro(st, o);
    ui.innerHTML = `
      <section id="screen-play" class="screen">
        <div class="scene-panel">
          <div class="scene-head">
            <span class="scene-stage">${st.stage} • พ.ศ. ${th(st.year)} • อายุ ${th(st.age)} ปี</span>
            <h2 class="scene-title">${st.title}</h2>
          </div>
          <div class="scene-text">${intro}</div>
          <div class="choice-list">
            ${choices.map((c, i) => `
              <button class="choice-btn" data-i="${i}">
                <span class="c-num">${i + 1}</span>
                <span class="c-ico">${c.ico}</span>
                <span class="c-txt">${c.text}</span>
                <span class="c-hint">${c.hint}</span>
              </button>`).join("")}
          </div>
        </div>
      </section>`;
    ui.querySelectorAll(".choice-btn").forEach(b => {
      b.onclick = () => chooseChoice(st, +b.dataset.i, b);
    });
  }

  function idx0Intro(st, o) {
    if (st.id === "child") return esc(o.intro) + "<br><br>" + esc(st.intro({ name: `<b>${G.name}</b>` })).replace(/&lt;b&gt;|&lt;\/b&gt;/g, (m) => m.includes("/") ? "</b>" : "<b>");
    return esc(st.intro({ name: G.name }));
  }

  function chooseChoice(st, i, btn) {
    if (modalOpen) return;
    const c = G._currentChoices[i];
    AudioSys.sfx("chime");
    ui.querySelectorAll(".choice-btn").forEach(b => b.disabled = true);
    btn.classList.add("picked");
    setTimeout(() => resolveChoice(st, c), 420);
  }

  function resolveChoice(st, c) {
    if (c.flag && !G.flags.includes(c.flag)) G.flags.push(c.flag);
    const deltas = applyEffects(c.eff, true);
    animateStatDeltas(Object.fromEntries(deltas));
    const dMap = Object.fromEntries(deltas);
    const good = deltas.reduce((s, [, v]) => s + v, 0) >= 0;
    setTimeout(() => AudioSys.sfx(good ? "good" : "bad"), 250);
    G.log.push({ year: st.year, text: c.text });

    const chips = deltas.map(([k, v]) =>
      `<span class="fx-chip ${v >= 0 ? "up" : "down"}">${D.statMeta[k].ico} ${D.statMeta[k].name} ${v >= 0 ? "+" : ""}${v}</span>`).join("");

    const panel = document.querySelector(".scene-panel");
    panel.innerHTML = `
      <div class="scene-head"><span class="scene-stage">${st.stage} • ผลลัพธ์</span></div>
      <div class="result-panel">
        <p class="result-text">${esc(c.result({ name: G.name }))}</p>
        <div class="result-effects">${chips}</div>
      </div>
      <div class="center-row"><button id="btn-next" class="btn btn-primary">ดำเนินชีวิตต่อ →</button></div>`;
    document.getElementById("btn-next").onclick = () => afterStage(st);
  }

  function afterStage(st) {
    AudioSys.sfx("page");
    if (checkDeath()) { screenEnding(); return; }
    // อีเวนต์ย่อย 40%
    if (Math.random() < 0.42) {
      const pool = D.miniEvents.filter(e => {
        if (st.year < e.years[0] || st.year > e.years[1]) return false;
        if (e.tags) {
          const o = D.origins.find(x => x.id === G.origin) || D.origins[0];
          if (!e.tags.some(t => o.tags.includes(t))) return false;
        }
        return true;
      });
      if (pool.length) {
        const e = pick(pool);
        let eff = { ...e.eff };
        if (e.luckBased && Math.random() < 0.3) eff = { gold: 25, joy: 8 };
        showModal({ ribbon: "🎋 เรื่องราวระหว่างทาง", year: "พ.ศ. " + th(st.year + Math.floor(rnd(0, 3))), title: e.title, text: e.text, effect: eff }, () => {
          if (checkDeath()) { screenEnding(); return; }
          advance(st);
        });
        return;
      }
    }
    advance(st);
  }

  function advance(st) {
    if (G.stageIdx + 1 < D.stages.length) {
      fade(() => playStage(G.stageIdx + 1));
    } else {
      screenEnding();
    }
  }

  /* ---------- หน้าจบ ---------- */
  function screenEnding() {
    screen = "ending";
    AudioSys.sfx(G.dead ? "sigh" : "unlock");
    const ending = D.endings.find(e => e.cond(G));
    const isNew = !records.endings.includes(ending.id);
    if (isNew) records.endings.push(ending.id);
    records.lives++;

    // ความฝัน
    const dream = D.dreams.find(d => d.id === G.dream);
    let dreamScore = 0;
    if (dream) {
      dreamScore = dream.id === "joy" ? Math.round((G.stats.joy + G.stats.hp) / 2) : G.stats[dream.stat];
    }
    const dreamOK = dreamScore >= 70, dreamMid = dreamScore >= 50;
    const bonus = dreamOK ? 40 : dreamMid ? 15 : 0;
    const score = G.dead
      ? Math.round((G.stats.hp + G.stats.wis + G.stats.gold + G.stats.honor + G.stats.joy) / 2)
      : G.stats.hp + G.stats.wis + G.stats.gold + G.stats.honor + G.stats.joy + bonus;
    const isBest = score > records.best;
    if (isBest) records.best = score;
    saveRecords();

    const lifespan = G.dead ? `จากโลกนี้ไปในปี พ.ศ. ${th(G.year + Math.floor(rnd(1, 3)))}` : "ใช้ชีวิตยืนยาวจนถึงยุคใหม่";
    const story = ending.story({ name: G.name });

    setBG("night", "firefly");
    const s = G.stats;
    const originObj = D.origins.find(o => o.id === G.origin) || D.origins[0];
    ui.innerHTML = `
      <section id="screen-ending" class="screen">
        <div class="paper-panel ending-panel">
          <div class="ending-kicker">${isNew ? "✨ ปลดล็อกตอนจบใหม่! ✨" : "ตอนจบที่เคยพบแล้ว"}</div>
          <h2 class="ending-title">${ending.ico} ${ending.title}</h2>
          <div class="ending-life">${esc(G.name)} • ${originObj.name} • ${lifespan}</div>
          <div class="ending-dream ${dreamOK ? "ok" : dreamMid ? "mid" : "no"}">
            ${dream ? `${dream.ico} ความฝัน “${dream.name}” — ${dreamOK ? "สำเร็จดั่งใจ!" : dreamMid ? "ใกล้เคียงกับฝัน" : "ฝันไม่เป็นจริง แต่ชีวิตยังมีค่า"}` : ""}
          </div>
          <div class="ending-story">${esc(story)}</div>
          <div class="ending-stats">
            ${["hp", "wis", "gold", "honor", "joy"].map(k => `
              <div class="ending-stat"><b>${th(s[k])}</b>${D.statMeta[k].ico} ${D.statMeta[k].name}</div>`).join("")}
          </div>
          <div class="ending-score">🏅 คะแนนบารมี: ${th(score)} ${isBest ? '<span class="ending-new">สถิติใหม่!</span>' : ""}</div>
          <ul class="life-log">${G.log.map(l => `<li><b>พ.ศ. ${th(l.year)}</b> — ${esc(l.text)}</li>`).join("")}</ul>
          <div class="center-row" style="gap:12px;flex-wrap:wrap">
            <button id="btn-again" class="btn btn-primary">🌱 เกิดใหม่อีกชีวิต</button>
            <button id="btn-gal2" class="btn">📖 คลังตอนจบ (${th(records.endings.length)}/${th(D.endings.length)})</button>
            <button id="btn-home" class="btn">🏠 หน้าปก</button>
          </div>
        </div>
      </section>`;
    if (isNew && !G.dead) {
      const rect = ui.querySelector(".ending-panel").getBoundingClientRect();
      FX.burst(rect.left + rect.width / 2, rect.top + 60);
    }
    document.getElementById("btn-again").onclick = () => { AudioSys.sfx("page"); setupSel.origin = null; setupSel.dream = null; setupSel.name = ""; screenSetup(0); };
    document.getElementById("btn-gal2").onclick = () => { AudioSys.sfx("page"); screenGallery(); };
    document.getElementById("btn-home").onclick = () => { AudioSys.sfx("page"); screenTitle(); };
  }

  /* ---------- คลังตอนจบ ---------- */
  function screenGallery() {
    screen = "gallery";
    setBG("forest", "petal");
    ui.innerHTML = `
      <section id="screen-gallery" class="screen">
        <div class="paper-panel gallery-panel">
          <div class="gallery-head">
            <h2>📖 คลังตอนจบ</h2>
            <span class="gallery-count">ปลดล็อก ${th(records.endings.length)} / ${th(D.endings.length)}</span>
          </div>
          <div class="gallery-grid">
            ${D.endings.map(e => {
              const got = records.endings.includes(e.id);
              return `<div class="g-card ${got ? "" : "locked"}">
                <div class="g-ico">${got ? e.ico : "❔"}</div>
                <h4>${got ? e.title : "ยังไม่เคยพบ"}</h4>
                <p>${got ? "เคยใช้ชีวิตถึงตอนจบนี้แล้ว" : "ใช้ชีวิตให้ถึงเส้นทางนี้เพื่อปลดล็อก"}</p>
              </div>`;
            }).join("")}
          </div>
          <div class="center-row" style="margin-top:16px">
            <button id="btn-back" class="btn btn-primary">← กลับ</button>
          </div>
        </div>
      </section>`;
    document.getElementById("btn-back").onclick = () => { AudioSys.sfx("page"); screenTitle(); };
  }

  /* ---------- ปุ่มระบบ ---------- */
  const btnMute = document.getElementById("btn-mute");
  function syncMute() { btnMute.textContent = AudioSys.muted ? "🔕" : "🔔"; }
  btnMute.onclick = () => { AudioSys.unlock(); AudioSys.setMuted(!AudioSys.muted); syncMute(); if (!AudioSys.muted) AudioSys.sfx("click"); };
  syncMute();

  document.getElementById("btn-pause").onclick = togglePause;
  function togglePause() {
    if (screen !== "play") return;
    paused = !paused;
    pauseEl.classList.toggle("hidden", !paused);
    AudioSys.sfx("click");
  }
  document.getElementById("pause-resume").onclick = togglePause;
  document.getElementById("pause-restart").onclick = () => { paused = false; pauseEl.classList.add("hidden"); setupSel.origin = null; setupSel.dream = null; setupSel.name = ""; screenSetup(0); };
  document.getElementById("pause-title").onclick = () => { paused = false; pauseEl.classList.add("hidden"); screenTitle(); };

  /* ---------- คีย์บอร์ด ---------- */
  document.addEventListener("keydown", (ev) => {
    if (ev.key === "m" || ev.key === "M") { btnMute.onclick(); return; }
    if (ev.key === "Escape") { togglePause(); return; }
    if (paused) return;
    if (modalOpen && (ev.key === "Enter" || ev.key === " ")) {
      ev.preventDefault();
      document.getElementById("modal-ok").click(); return;
    }
    if (screen === "title" && (ev.key === "Enter" || ev.key === " ")) {
      ev.preventDefault(); document.getElementById("btn-start").click(); return;
    }
    if (screen === "play") {
      const next = document.getElementById("btn-next");
      if (next && (ev.key === "Enter" || ev.key === " ")) { ev.preventDefault(); next.click(); return; }
      const idx = ["1", "2", "3"].indexOf(ev.key);
      if (idx >= 0) {
        const btns = ui.querySelectorAll(".choice-btn");
        if (btns[idx]) btns[idx].click();
      }
    }
  });

  // ปลดล็อกเสียงด้วยการสัมผัสครั้งแรก (autoplay policy)
  document.addEventListener("pointerdown", () => AudioSys.unlock(), { once: true });

  /* ---------- เริ่มเกม ---------- */
  screenTitle();
})();